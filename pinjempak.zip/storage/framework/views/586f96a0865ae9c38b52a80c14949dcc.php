

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center py-6">
        <div class="bg-white rounded-3xl p-10 w-full max-w-3xl shadow-xl border border-gray-600">
            <h2 class="text-4xl text-center mb-8 font-normal">Tambah Barang</h2>
            
            <form action="<?php echo e(route('store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="mb-4">
                    <label class="block text-xl mb-2">Upload foto:</label>
                    <div class="relative w-40 h-24">
                        <div id="preview-container" class="bg-gray-100 w-full h-full rounded-2xl flex items-center justify-center overflow-hidden border-2 border-dashed border-gray-300 hover:border-custom-orange transition-colors">
                            <span id="preview-text" class="text-gray-500 text-sm">#foto barang</span>
                            <img id="preview-image" src="" alt="Preview" class="w-full h-full object-cover hidden">
                        </div>
                        <input type="file" name="gambar_barang" id="gambar_barang" accept="image/*" 
                            class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" onchange="previewImage(event)">
                    </div>
                    <?php $__errorArgs = ['gambar_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-xl mb-2">Nama barang:</label>
                    <input type="text" name="nama_barang" value="<?php echo e(old('nama_barang')); ?>" 
                        class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm" required>
                </div>

                <div class="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xl mb-2">Kategori:</label>
                        <select name="kategori" class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm cursor-pointer bg-white" required>
                            <option value="" disabled selected>-- Pilih Kategori --</option>
                            <option value="Elektronik" <?php echo e(old('kategori') == 'Elektronik' ? 'selected' : ''); ?>>Elektronik</option>
                            <option value="Alat" <?php echo e(old('kategori') == 'Alat' ? 'selected' : ''); ?>>Alat</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-xl mb-2">Stok:</label>
                        <input type="number" name="stok" value="<?php echo e(old('stok')); ?>" min="1"
                            class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-xl mb-2">Status:</label>
                    <input type="text" name="status" value="Tersedia" readonly
                        class="w-1/2 rounded-2xl border-none p-4 text-lg bg-gray-200 cursor-not-allowed text-gray-600 outline-none">
                </div>

                <div class="mb-8">
                    <label class="block text-xl mb-2">Deskripsi:</label>
                    <textarea name="deskripsi" rows="3" class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm"><?php echo e(old('deskripsi')); ?></textarea>
                </div>

                <div class="flex justify-center gap-6">
                    <a href="<?php echo e(route('home')); ?>" class="bg-white text-black text-xl px-10 py-3 rounded-full shadow hover:bg-gray-50">
                        Batal
                    </a>
                    <button type="submit" class="bg-custom-orange text-black text-xl px-10 py-3 rounded-full shadow hover:opacity-90">
                        Tambah
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function previewImage(event) {
            const input = event.target;
            const reader = new FileReader();
            
            reader.onload = function(){
                const dataURL = reader.result;
                const imageElement = document.getElementById('preview-image');
                const textElement = document.getElementById('preview-text');
                
                imageElement.src = dataURL;
                imageElement.classList.remove('hidden');
                textElement.classList.add('hidden');
            };
            
            if (input.files && input.files[0]) {
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/create.blade.php ENDPATH**/ ?>