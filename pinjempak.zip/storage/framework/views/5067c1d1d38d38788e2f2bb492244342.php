

<?php $__env->startSection('content'); ?>
    <div class="mt-6">
        <h1 class="text-3xl font-medium mb-6">Laporan Kerusakan</h1>

        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="flex flex-col gap-4">
            <?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-100 rounded-xl p-4 flex items-center justify-between">
                <div class="w-1/3">
                    <p class="text-xl font-medium"><?php echo e($loan->inventory->nama_barang); ?></p>
                    <p class="text-sm text-red-500">Rusak: <?php echo e($loan->jumlah); ?> item</p>
                </div>
                <div class="w-1/3 text-center">
                    <p class="text-lg"><?php echo e($loan->user->name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo e($loan->created_at->format('d M Y')); ?></p>
                </div>
                <div class="w-1/3 text-right">
                    <a href="<?php echo e(route('laporan.detail', $loan->id)); ?>" class="bg-custom-orange text-black text-lg px-8 py-2 rounded-full hover:opacity-90">
                        Cek
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-gray-500 text-xl mt-10">
                Tidak ada laporan kerusakan.
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/laporan.blade.php ENDPATH**/ ?>