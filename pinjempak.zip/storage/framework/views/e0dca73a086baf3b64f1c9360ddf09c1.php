

<?php $__env->startSection('content'); ?>
    <div class="mt-2 md:mt-6">
        
        <!-- Header & Tombol Export -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl md:text-3xl font-semibold text-gray-800">Riwayat Peminjaman</h1>
                <p class="text-sm text-gray-500 mt-1">Filter berdasarkan rentang tanggal atau tahun.</p>
            </div>
            
            <?php if(Auth::user()->role === 'petugas'): ?>
            <a href="<?php echo e(route('riwayat.export', request()->query())); ?>" class="bg-green-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-green-700 transition-colors shadow-sm flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                Download Excel
            </a>
            <?php endif; ?>
        </div>

        <!-- FILTER FORM -->
        <div class="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mb-6">
            <form action="<?php echo e(route('riwayat')); ?>" method="GET" class="flex flex-col lg:flex-row gap-4 items-end">
                
                <!-- Filter Tanggal -->
                <div class="flex flex-col w-full lg:w-auto">
                    <label class="text-xs font-semibold text-gray-600 mb-1">Dari Tanggal:</label>
                    <input type="date" name="start_date" value="<?php echo e($startDate); ?>" 
                        class="bg-gray-50 border border-gray-300 text-sm rounded-lg focus:ring-custom-orange focus:border-custom-orange block w-full p-2.5">
                </div>
                <div class="flex flex-col w-full lg:w-auto">
                    <label class="text-xs font-semibold text-gray-600 mb-1">Sampai Tanggal:</label>
                    <input type="date" name="end_date" value="<?php echo e($endDate); ?>" 
                        class="bg-gray-50 border border-gray-300 text-sm rounded-lg focus:ring-custom-orange focus:border-custom-orange block w-full p-2.5">
                </div>

                <span class="text-gray-400 font-medium pb-2.5 hidden lg:block">ATAU</span>

                <!-- Filter Tahun -->
                <div class="flex flex-col w-full lg:w-auto">
                    <label class="text-xs font-semibold text-gray-600 mb-1">Pilih Tahun:</label>
                    <select name="tahun" class="bg-gray-50 border border-gray-300 text-sm rounded-lg focus:ring-custom-orange focus:border-custom-orange block w-full p-2.5">
                        <option value="">-- Semua Tahun --</option>
                        <?php $__currentLoopData = $tahunTersedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($thn); ?>" <?php echo e($tahun == $thn ? 'selected' : ''); ?>><?php echo e($thn); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Tombol Aksi -->
                <div class="flex gap-2 w-full lg:w-auto">
                    <button type="submit" class="w-full lg:w-auto bg-custom-orange text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-orange-500 transition-colors">
                        Terapkan Filter
                    </button>
                    <a href="<?php echo e(route('riwayat')); ?>" class="w-full lg:w-auto bg-gray-100 text-gray-600 px-4 py-2.5 rounded-lg text-sm hover:bg-gray-200 transition-colors text-center">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- LIST DATA -->
        <div class="flex flex-col gap-4">
            <?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:shadow-md transition-shadow">
                
                <div class="w-full md:w-1/3">
                    <p class="text-lg font-semibold text-gray-800"><?php echo e($loan->inventory->nama_barang); ?></p>
                    <p class="text-sm text-gray-500">Jumlah: <?php echo e($loan->jumlah); ?> item</p>
                    <?php if(Auth::user()->role === 'petugas'): ?>
                        <p class="text-sm text-gray-500 mt-1">Oleh: <?php echo e($loan->nama_peminjam); ?></p>
                    <?php endif; ?>
                </div>

                <div class="w-full md:w-1/3 md:text-center flex md:block justify-between items-center border-t border-gray-50 md:border-none pt-3 md:pt-0">
                    <p class="text-sm text-gray-500 md:hidden">Tanggal Selesai:</p>
                    <p class="text-sm md:text-base text-gray-800 md:text-gray-500"><?php echo e($loan->updated_at->format('d M Y')); ?></p>
                </div>

                <div class="w-full md:w-1/3 text-left md:text-right border-t border-gray-50 md:border-none pt-3 md:pt-0">
                    <?php if($loan->status === 'dikembalikan'): ?>
                        <span class="bg-green-100 text-green-700 font-bold px-4 py-1.5 rounded-full text-sm inline-block">
                            Dikembalikan
                        </span>
                    <?php elseif($loan->status === 'ditolak'): ?>
                        <span class="bg-red-100 text-red-700 font-bold px-4 py-1.5 rounded-full text-sm inline-block">
                            Ditolak
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="bg-white rounded-2xl p-8 text-center text-gray-500 shadow-sm border border-gray-100">
                Tidak ada riwayat peminjaman pada periode/tahun yang dipilih.
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/riwayat.blade.php ENDPATH**/ ?>