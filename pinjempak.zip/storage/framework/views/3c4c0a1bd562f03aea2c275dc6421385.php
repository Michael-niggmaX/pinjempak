

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center mt-4 md:mt-8">
        <div class="bg-white rounded-3xl w-full max-w-2xl p-6 md:p-10 shadow-sm border border-gray-100">
            
            <div class="mb-8 border-b pb-4">
                <h2 class="text-2xl md:text-3xl font-semibold text-gray-800">Pengaturan Akun</h2>
                <p class="text-sm text-gray-500 mt-1">Kelola keamanan akun Anda di sini.</p>
            </div>

            <!-- Notifikasi Sukses -->
            <?php if(session('success')): ?>
                <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded-md mb-6 shadow-sm" role="alert">
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>

            <!-- Info Akun (Readonly) -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div>
                    <label class="block text-sm font-medium text-gray-500 mb-1">Nama Lengkap</label>
                    <input type="text" value="<?php echo e(Auth::user()->name); ?>" readonly
                        class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-700 outline-none cursor-not-allowed">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-500 mb-1">Email</label>
                    <input type="text" value="<?php echo e(Auth::user()->email); ?>" readonly
                        class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-700 outline-none cursor-not-allowed">
                </div>
            </div>

            <!-- Form Ganti Password -->
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Ganti Password</h3>
            <form action="<?php echo e(route('profile.password')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Password Lama -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password Lama</label>
                    <input type="password" name="current_password" required
                        class="w-full bg-white border border-gray-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all"
                        placeholder="Masukkan password saat ini">
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password Baru -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password Baru</label>
                    <input type="password" name="password" required
                        class="w-full bg-white border border-gray-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all"
                        placeholder="Minimal 6 karakter">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Konfirmasi Password Baru -->
                <div class="mb-8">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Konfirmasi Password Baru</label>
                    <input type="password" name="password_confirmation" required
                        class="w-full bg-white border border-gray-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all"
                        placeholder="Ulangi password baru">
                </div>

                <!-- Tombol Simpan -->
                <div class="flex justify-end">
                    <button type="submit" class="bg-custom-orange text-white font-medium px-8 py-3 rounded-xl hover:bg-orange-500 transition-colors shadow-sm">
                        Simpan Password Baru
                    </button>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/profile.blade.php ENDPATH**/ ?>