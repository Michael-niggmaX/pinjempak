

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center mt-2 md:mt-6 mb-10 md:mb-20"> 
        <div class="bg-white rounded-2xl w-full max-w-4xl p-6 md:p-8 shadow-sm border border-gray-100 flex flex-col min-h-[600px]">
            
            <div> 
                <h2 class="text-2xl md:text-3xl font-semibold mb-6 border-b pb-4 text-gray-800">Detail Peminjaman</h2>
                
                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded relative mb-6">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <div class="flex flex-col md:flex-row gap-6 md:gap-8">
                    <div class="w-full md:w-1/3">
                        <p class="text-lg mb-2 font-medium text-gray-800">Item: <?php echo e($loan->inventory->nama_barang); ?></p>
                        <div class="bg-gray-100 w-full h-48 rounded-xl overflow-hidden flex items-center justify-center border border-gray-200">
                            <?php if($loan->inventory->gambar_barang): ?>
                                <img src="<?php echo e(asset('images/' . $loan->inventory->gambar_barang)); ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <span class="text-gray-400">No Image</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="w-full md:w-2/3 space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <p class="text-gray-500 text-xs md:text-sm">Jumlah Pinjam</p>
                                <p class="text-lg font-medium"><?php echo e($loan->jumlah); ?> Unit</p>
                            </div>
                            <div>
                                <p class="text-gray-500 text-xs md:text-sm">Nama Peminjam</p>
                                <p class="text-lg font-medium"><?php echo e($loan->nama_peminjam); ?></p>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <p class="text-gray-500 text-xs md:text-sm">Kelas</p>
                                <p class="text-lg"><?php echo e($loan->kelas); ?></p>
                            </div>
                            <div>
                                <p class="text-gray-500 text-xs md:text-sm">Jurusan</p>
                                <p class="text-lg"><?php echo e($loan->jurusan === 'Guru' ? '-' : $loan->jurusan); ?></p>
                            </div>
                        </div>

                        <div>
                            <p class="text-gray-500 text-xs md:text-sm">Rencana Tanggal Kembali</p>
                            <p class="text-lg font-medium text-custom-orange"><?php echo e(\Carbon\Carbon::parse($loan->tanggal_kembali_request)->format('d M Y')); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-gray-500 text-xs md:text-sm">Alasan Peminjaman</p>
                            <p class="text-base bg-gray-50 p-3 rounded-lg border border-gray-100 mt-1"><?php echo e($loan->alasan); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-auto pt-8 flex flex-col md:flex-row justify-end w-full">
                <?php if($loan->status === 'pending'): ?>
                    <?php if(Auth::user()->role === 'petugas'): ?>
                        
                        <div class="w-full md:w-2/3 bg-gray-50 p-4 rounded-xl border border-gray-200 flex flex-col gap-4">
                            
                            <div class="flex flex-col md:flex-row gap-3">
                                <div class="flex flex-col flex-1">
                                    <label class="text-xs font-semibold text-gray-600 mb-1">Tgl Disetujui:</label>
                                    <input type="date" name="tanggal_kembali_disetujui" form="form-konfirmasi"
                                        value="<?php echo e($loan->tanggal_kembali_request); ?>" 
                                        min="<?php echo e(date('Y-m-d')); ?>" required
                                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-custom-orange bg-white">
                                </div>
                                <div class="flex flex-col flex-1">
                                    <label class="text-xs font-semibold text-gray-600 mb-1">Catatan (Opsional):</label>
                                    <input type="text" name="catatan_admin" form="form-konfirmasi" placeholder="Misal: Maksimal 2 hari" 
                                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-custom-orange bg-white">
                                </div>
                            </div>

                            <div class="flex flex-col md:flex-row justify-end gap-3 pt-2">
                                <form action="<?php echo e(route('pending.tolak', $loan->id)); ?>" method="POST" onsubmit="return confirm('Yakin menolak peminjaman ini?');" class="w-full md:w-auto m-0">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="w-full bg-white text-gray-700 text-base font-medium px-6 py-2.5 rounded-xl hover:bg-gray-100 transition-colors border border-gray-300">
                                        Tolak
                                    </button>
                                </form>

                                <form id="form-konfirmasi" action="<?php echo e(route('pending.konfirmasi', $loan->id)); ?>" method="POST" class="w-full md:w-auto m-0">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="w-full bg-custom-orange text-white text-base font-medium px-8 py-2.5 rounded-xl hover:bg-orange-500 transition-colors shadow-sm">
                                        Konfirmasi
                                    </button>
                                </form>
                            </div>

                        </div>

                    <?php else: ?>
                        <a href="<?php echo e(route('pending')); ?>" class="w-full md:w-auto bg-gray-100 text-center text-gray-700 text-base font-medium px-8 py-3 rounded-xl hover:bg-gray-200 transition-colors border border-gray-200">
                            Kembali
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('pending')); ?>" class="w-full md:w-auto bg-gray-100 text-center text-gray-700 text-base font-medium px-8 py-3 rounded-xl hover:bg-gray-200 transition-colors border border-gray-200">
                        Kembali
                    </a>
                <?php endif; ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/pending-show.blade.php ENDPATH**/ ?>