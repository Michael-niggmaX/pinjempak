

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center mt-4">
        <div class="bg-gray-100 rounded-xl w-full max-w-4xl p-8 shadow-sm relative">
            
            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-gray-300 w-full h-72 md:h-96 mb-6 rounded-lg overflow-hidden flex items-center justify-center">
                <?php if($item->gambar_barang): ?>
                    <img src="<?php echo e(asset('images/' . $item->gambar_barang)); ?>" alt="<?php echo e($item->nama_barang); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <span class="text-gray-500 text-xl">No Image</span>
                <?php endif; ?>
            </div>

            <div class="flex justify-between items-center mb-6 border-b pb-4">
                <h1 class="text-3xl font-medium"><?php echo e($item->nama_barang); ?></h1>
                <span class="text-xl font-medium"><?php echo e($item->status); ?></span>
            </div>

            <div class="mb-20">
                <p class="text-xl mb-2"><span class="font-normal">Kategori:</span> <?php echo e($item->kategori); ?></p>
                                <p class="text-xl mb-2"><span class="font-normal">Stok Tersedia:</span> <?php echo e($item->stok); ?></p>
                <p class="text-xl mb-4"><span class="font-normal">Stok Rusak:</span> <?php echo e($item->stok_rusak ?? 0); ?></p>
                <p class="text-lg text-gray-700 leading-relaxed">
                    <?php echo e($item->deskripsi ?? 'Tidak ada deskripsi.'); ?>

                </p>
            </div>

            <div class="absolute bottom-8 right-8">
                <?php if(Auth::user()->role === 'petugas'): ?>
                    <a href="<?php echo e(route('edit', $item->id)); ?>" class="bg-custom-orange text-black text-xl px-12 py-3 rounded-full shadow hover:opacity-90 transition">
                        Edit Barang
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('pinjam.create', $item->id)); ?>" class="bg-custom-orange text-black text-xl px-12 py-3 rounded-full shadow hover:opacity-90 transition block text-center">
    Pinjam
</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/show.blade.php ENDPATH**/ ?>