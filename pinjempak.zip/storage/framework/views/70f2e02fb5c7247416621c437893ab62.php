

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center mt-6">
        <div class="bg-gray-100 rounded-2xl w-full max-w-4xl p-8 shadow-sm relative pb-24">
            
            <h2 class="text-3xl font-medium mb-6">Laporan Kerusakan</h2>

            <div class="mb-6">
                <p class="text-lg mb-2">Bukti</p>
                <div class="bg-gray-300 w-full h-64 md:h-80 rounded-lg overflow-hidden flex items-center justify-center">
                    <?php if($loan->foto_bukti): ?>
                        <img src="<?php echo e(asset('images/' . $loan->foto_bukti)); ?>" class="w-full h-full object-contain">
                    <?php else: ?>
                        <span class="text-gray-500">Tidak ada foto bukti</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="space-y-2 mb-8">
                <p class="text-lg">Nama item: <span class="font-medium"><?php echo e($loan->inventory->nama_barang); ?></span></p>
                <p class="text-lg">Jumlah Rusak: <span class="font-medium text-red-500"><?php echo e($loan->jumlah); ?></span></p>
                <p class="text-lg">Detail: <span class="font-medium"><?php echo e($loan->detail_kerusakan); ?></span></p>
            </div>

            <div class="absolute bottom-8 right-8">
                <form action="<?php echo e(route('laporan.konfirmasi', $loan->id)); ?>" method="POST" onsubmit="return confirm('Konfirmasi kerusakan ini? Stok barang akan dikurangi.');">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-custom-orange text-black text-xl px-10 py-3 rounded-full hover:opacity-90 transition">
                        Konfirmasi
                    </button>
                </form>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/laporan-detail.blade.php ENDPATH**/ ?>