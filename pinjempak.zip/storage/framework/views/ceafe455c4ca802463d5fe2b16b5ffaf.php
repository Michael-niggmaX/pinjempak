

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center py-6">
        <div class="bg-white rounded-3xl p-10 w-full max-w-3xl shadow-xl border border-gray-100">
            <h2 class="text-4xl text-center mb-8 font-normal text-gray-800">Pinjam Barang</h2>
            
            <form action="<?php echo e(route('pinjam.store', $item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="mb-4">
                    <label class="block text-xl mb-2">Nama Barang:</label>
                    <input type="text" value="<?php echo e($item->nama_barang); ?>" readonly
                        class="w-1/2 rounded-xl border border-gray-200 p-4 text-lg bg-gray-100 text-gray-500 cursor-not-allowed outline-none">
                </div>

                <div class="mb-4">
                    <label class="block text-xl mb-2">Jumlah:</label>
                    <input type="number" name="jumlah" value="1" min="1" max="<?php echo e($item->stok); ?>" required
                        class="w-1/2 rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm">
                    <p class="text-sm text-gray-500 mt-1">Stok tersedia: <?php echo e($item->stok); ?></p>
                    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-xl mb-2">Nama Peminjam:</label>
                    <input type="text" name="nama_peminjam" value="<?php echo e(auth()->user()->name); ?>" readonly
                        class="w-full rounded-xl border border-gray-200 p-4 text-lg bg-gray-100 text-gray-500 cursor-not-allowed outline-none">
                </div>

                <?php if(auth()->user()->role === 'siswa'): ?>
                <div class="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xl mb-2">Kelas:</label>
                        <input type="text" name="kelas" placeholder="Contoh: XII" required
                            class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xl mb-2">Jurusan:</label>
                        <input type="text" name="jurusan" placeholder="Contoh: RPL" required
                            class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm">
                    </div>
                </div>
                <?php endif; ?>

                <div class="mb-4">
                    <label class="block text-xl mb-2">Tanggal Rencana Kembali:</label>
                    <input type="date" name="tanggal_kembali_request" required min="<?php echo e(date('Y-m-d')); ?>"
                        class="w-1/2 rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm bg-white">
                    <?php $__errorArgs = ['tanggal_kembali_request'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-8">
                    <label class="block text-xl mb-2">Tujuan:</label>
                    <textarea name="alasan" rows="3" required class="w-full rounded-xl border border-gray-300 p-4 text-lg focus:ring-2 focus:ring-custom-orange focus:border-transparent outline-none transition-all shadow-sm"></textarea>
                </div>

                <div class="flex justify-center gap-6">
                    <a href="<?php echo e(route('home')); ?>" class="bg-gray-100 text-gray-700 text-xl px-10 py-3 rounded-full shadow-sm hover:bg-gray-200 transition-colors">
                        Batal
                    </a>
                    <button type="submit" class="bg-custom-orange text-white text-xl px-10 py-3 rounded-full shadow-md hover:bg-orange-500 transition-colors">
                        Pinjam
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pinjempak\resources\views/pinjam.blade.php ENDPATH**/ ?>